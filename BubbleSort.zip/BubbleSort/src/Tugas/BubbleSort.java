package Tugas;

/**
 * mengurutkan nama superhero dengan Bubble sort
 * kelas : 2C TI
 *
 * by : Riky raharjo
 */

public class BubbleSort {
    private String[] nama;

    public BubbleSort() {
    }

    public String[] getNama() {
        return nama;
    }

    public void setNama(String[] nama) {
        this.nama = nama;
    }

    public void sortNama() {
        for (int i = 0; i < nama.length; i++) {
            for (int j = 0; j < nama.length; j++) {
                if (this.nama[j].compareTo(this.nama[i]) > 0) {
                    String temp = nama[i];
                    nama[i] = nama[j];
                    nama[j] = temp;
                }
            }
        }
    }

    public void printNama(){
        for (String name : this.nama){
            System.out.print( name + " ");
        }
    }

    public static void main(String[] args) {
        String[] s = new String[] {"Spiderman","Hulk","Batman","Ironman","Ultramen"};
        BubbleSort _myBubble = new BubbleSort();
        _myBubble.setNama(s);
        _myBubble.sortNama();
        _myBubble.printNama();
    }
}
